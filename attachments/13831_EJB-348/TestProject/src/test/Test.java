package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import model.Computer;
import model.IPAddress;
import model.NetworkInterface;

public class Test {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("TEST");

		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;

		try {
			entityManager = factory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();

			Computer computer = new Computer();

			// ASSIGNED ID
			computer.setId("COMPUTER1");
			computer.setAssetTag("AC1");

			NetworkInterface networkInterface = new NetworkInterface();
			networkInterface.setMacAddress("00:00:00:00:00:00");

			computer.addNetworkInterface(networkInterface);

			IPAddress ipAddress1 = new IPAddress();
			ipAddress1.setIpAddress("192.168.1.1");

			networkInterface.addIpAddress(ipAddress1);

			IPAddress ipAddress2 = new IPAddress();
			ipAddress2.setIpAddress("192.168.1.2");

			networkInterface.addIpAddress(ipAddress2);

			// NetworkInterface(*) and IPAddress(*) supposed to CASCADE on
			// persist
			entityManager.persist(computer);

			entityTransaction.commit();

		} catch (Throwable error) {
			error.printStackTrace();
			if (entityTransaction != null) {
				entityTransaction.rollback();
			}
		} finally {

			if (entityManager != null) {
				entityManager.close();
			}

			if (factory != null) {
				factory.close();
			}
		}

	}
}
