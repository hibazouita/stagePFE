package model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@Entity
@Table(name = "CMP")
public class Computer implements Serializable {
	private final static long serialVersionUID = 1L;
	private String id;
	private String assetTag;
	private Set<NetworkInterface> networkInterfaces;

	public Computer() {
		super();
		networkInterfaces = new HashSet<NetworkInterface>();
	}

	@Id
	@Column(name = "CMP_ID")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Column(name = "ASSET_TAG")
	public String getAssetTag() {
		return assetTag;
	}

	public void setAssetTag(String assetTag) {
		this.assetTag = assetTag;
	}

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "computer")
	@JoinColumn(name = "COMPUTER_ID")
	public Set<NetworkInterface> getNetworkInterfaces() {
		return networkInterfaces;
	}

	public void setNetworkInterfaces(Set<NetworkInterface> networkInterfaces) {
		this.networkInterfaces = networkInterfaces;
	}

	public void addNetworkInterface(NetworkInterface networkInterface) {

		if (!networkInterfaces.contains(networkInterface)) {
			networkInterfaces.add(networkInterface);
		}

		networkInterface.setComputer(this);
	}

	public boolean equals(Object obj) {
		if (obj instanceof Computer == false) {
			return false;
		}
		if (this == obj) {
			return true;
		}
		Computer rhs = (Computer) obj;
		return new EqualsBuilder().append(id, rhs.id).append(assetTag,
				rhs.assetTag).isEquals();
	}

	public int hashCode() {
		return new HashCodeBuilder(17, 31).append(id).append(assetTag)
				.toHashCode();
	}
}
