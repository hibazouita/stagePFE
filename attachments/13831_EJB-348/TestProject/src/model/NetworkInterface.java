package model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@Entity
@Table(name = "NI")
public class NetworkInterface implements Serializable {
	private final static long serialVersionUID = 1L;
	private long id;
	private Set<IPAddress> ipAddresses;
	private String macAddress;
	private Computer computer;

	public NetworkInterface() {
		super();
		ipAddresses = new HashSet<IPAddress>();
	}

	@TableGenerator(name = "NI_GENERATOR", table = "KEYGENERATOR", pkColumnName = "PRIMARY_KEY_COLUMN", valueColumnName = "VALUE_COLUMN")
	@Id
	@Column(name = "NI_ID")
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "NI_GENERATOR")
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "networkInterface")
	@JoinColumn(name = "IP_ID")
	public Set<IPAddress> getIpAddresses() {
		return ipAddresses;
	}

	public void setIpAddresses(Set<IPAddress> ipAddresses) {
		this.ipAddresses = ipAddresses;
	}

	@Column(name = "MAC_ADDRESS")
	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CMP_ID", nullable = false)
	public Computer getComputer() {
		return computer;
	}

	public void setComputer(Computer computer) {
		this.computer = computer;
	}

	public void addIpAddress(IPAddress ipAddress) {
		if (!ipAddresses.contains(ipAddress)) {
			ipAddresses.add(ipAddress);
		}

		ipAddress.setNetworkInterface(this);
	}

	public boolean equals(Object obj) {
		if (obj instanceof NetworkInterface == false) {
			return false;
		}
		if (this == obj) {
			return true;
		}
		NetworkInterface rhs = (NetworkInterface) obj;
		return new EqualsBuilder().append(macAddress, rhs.macAddress).append(
				computer, rhs.computer).isEquals();
	}

	public int hashCode() {
		return new HashCodeBuilder(17, 31).append(macAddress).append(computer)
				.toHashCode();
	}

}
