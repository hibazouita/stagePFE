package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@Entity
@Table(name = "IP")
public class IPAddress implements Serializable {
	private final static long serialVersionUID = 1L;
	private long id;
	private String ipAddress;
	private NetworkInterface networkInterface;

	public IPAddress() {
		super();
	}

	@TableGenerator(name = "IP_GENERATOR", table = "KEYGENERATOR", pkColumnName = "PRIMARY_KEY_COLUMN", valueColumnName = "VALUE_COLUMN")
	@Id
	@Column(name = "IP_ID")
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "IP_GENERATOR")
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Column(name = "IP_ADDRESS")
	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "NI_ID", nullable = false)
	public NetworkInterface getNetworkInterface() {
		return networkInterface;
	}

	public void setNetworkInterface(NetworkInterface networkInterface) {
		this.networkInterface = networkInterface;
	}

	public boolean equals(Object obj) {
		if (obj instanceof IPAddress == false) {
			return false;
		}
		if (this == obj) {
			return true;
		}
		IPAddress rhs = (IPAddress) obj;
		return new EqualsBuilder().append(ipAddress, rhs.ipAddress).append(
				networkInterface, rhs.networkInterface).isEquals();
	}

	public int hashCode() {
		return new HashCodeBuilder(17, 31).append(ipAddress).append(
				networkInterface).toHashCode();
	}
}
