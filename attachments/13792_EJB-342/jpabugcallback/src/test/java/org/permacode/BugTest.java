package org.permacode;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BugTest
{
    private static final String JDBC_PASSWORD = "";

    private static final String JDBC_USERNAME = "";

    private static final String JDBC_DRIVER =
        "com.p6spy.engine.spy.P6SpyDriver";

    private static final String JDBC_ATOMIC_TEST =
        "jdbc:derby:derby_db;create=true;derby.system.durability=test";

    private EntityManagerFactory entityManagerFactory;

    private Connection connection;

    private Statement statement;

    @Before
    public void start() throws Exception
    {
        startDatabase();
        entityManagerFactory =
            startHibernate("TestHibernate",
                "org.hibernate.dialect.DerbyDialect");
    }

    @After
    public void tearDown() throws SQLException
    {
        if (statement != null)
            statement.close();
        if (connection != null)
            connection.close();
    }

    public void startDatabase() throws Exception
    {
        Class.forName(JDBC_DRIVER);
        connection =
            DriverManager.getConnection(JDBC_ATOMIC_TEST, JDBC_USERNAME,
                JDBC_PASSWORD);
        statement = connection.createStatement();
        if (isSchemaSetup(connection, null))
        {
            killSchema(connection, "DEV");
        }
        statement.execute("create schema DEV");
        statement.execute("set schema DEV");
        statement
            .execute("create table HABITAT (ID integer,TITLE varchar(255) not null,OWNER_ID integer not null,VERSION integer not null,CREATED timestamp not null,MODIFIED timestamp not null,constraint HABITAT_PK primary key (ID), constraint HABITAT_TITLE_U unique (TITLE))");
        statement
            .execute("create table KEY_SEQUENCE (TABLE_SEQ varchar(50) not null,LAST_KEY integer not null,constraint KEY_SEQUENCE_PK primary key (TABLE_SEQ))");
        statement
            .execute("insert into KEY_SEQUENCE (TABLE_SEQ,LAST_KEY) values ('HABITAT',333)");
        statement
            .execute("insert into HABITAT (ID,TITLE,OWNER_ID,VERSION,CREATED,MODIFIED) values (1, 'Habitat Title', 234, 1, '2008-03-01 00:00:00.0','2008-03-02 00:00:00.0')");
    }

    private static EntityManagerFactory startOpenJpa(String persistenceUnit,
        String dialect)
    {
        Map map = new HashMap();
        map.put("openjpa.jdbc.DBDictionary", dialect);
        map.put("openjpa.jdbc.SchemaFactory", "native(ForeignKeys=true)");
        map.put("openjpa.ConnectionURL", JDBC_ATOMIC_TEST);
        map.put("openjpa.ConnectionDriverName", JDBC_DRIVER);
        map.put("openjpa.ConnectionUserName", JDBC_USERNAME);
        map.put("openjpa.ConnectionPassword", JDBC_PASSWORD);
        return Persistence.createEntityManagerFactory(persistenceUnit, map);
    }

    private static EntityManagerFactory startToplink(String persistenceUnit,
        String dialect)
    {
        Map map = new HashMap();
        map.put("toplink.logging.level", "INFO");
        map.put("toplink.target-database", dialect);
        map.put("toplink.jdbc.url", JDBC_ATOMIC_TEST);
        map.put("toplink.jdbc.driver", JDBC_DRIVER);
        map.put("toplink.jdbc.user", JDBC_USERNAME);
        map.put("toplink.jdbc.password", JDBC_PASSWORD);
        return Persistence.createEntityManagerFactory(persistenceUnit, map);
    }

    private static EntityManagerFactory startHibernate(String persistenceUnit,
        String dialect)
    {
        Map map = new HashMap();
        map.put("hibernate.dialect", dialect);
        map.put("hibernate.connection.url", JDBC_ATOMIC_TEST);
        map.put("hibernate.connection.driver_class", JDBC_DRIVER);
        map.put("hibernate.connection.username", JDBC_USERNAME);
        map.put("hibernate.connection.password", JDBC_PASSWORD);
        return Persistence.createEntityManagerFactory(persistenceUnit, map);
    }

    private DataSource createDataSource()
    {
        DataSource ds = new DataSource()
        {
            public Connection getConnection() throws SQLException
            {
                String jdbcURL = JDBC_ATOMIC_TEST;
                String jdbcDriver = JDBC_DRIVER;
                String userName = JDBC_USERNAME;
                String password = JDBC_PASSWORD;
                try
                {
                    Class.forName(jdbcDriver);
                }
                catch (ClassNotFoundException e)
                {
                    e.printStackTrace();
                    return null;
                }
                return DriverManager.getConnection(jdbcURL, userName, password);
            }

            public Connection getConnection(String newUsername,
                String newPassword) throws SQLException
            {
                throw new RuntimeException("not supporting");
            }

            public PrintWriter getLogWriter() throws SQLException
            {
                throw new RuntimeException("not supporting");
            }

            public int getLoginTimeout() throws SQLException
            {
                throw new RuntimeException("not supporting");
            }

            public void setLogWriter(PrintWriter newOut) throws SQLException
            {
                throw new RuntimeException("not supporting");
            }

            public void setLoginTimeout(int newSeconds) throws SQLException
            {
                throw new RuntimeException("not supporting");
            }
        };
        return ds;
    }

    public boolean isSchemaSetup(Connection connection, String schema)
        throws SQLException
    {
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet rs =
            metaData.getTables(null, schema, null, new String[] { "TABLE" });
        boolean hasTables = false;
        while (rs.next())
        {
            System.out.println("Schema " + schema + " has table '"
                + rs.getString("TABLE_NAME") + "'");
            hasTables = true;
        }
        rs.close();
        return hasTables;
    }

    public void killSchema(Connection connection, String schema)
        throws SQLException
    {
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet rs =
            metaData.getTables(null, schema, null, new String[] { "TABLE" });
        if (schema == null)
            schema = "";
        if (schema != null && schema.length() > 0)
            schema += ".";
        while (rs.next())
        {
            statement.executeUpdate("drop table " + schema
                + rs.getString("TABLE_NAME"));
        }
        rs.close();
        statement.executeUpdate("drop schema DEV restrict");
    }

    @Test
    public void testFind() throws Exception
    {
        EntityManager entityManager =
            entityManagerFactory.createEntityManager();
        Query query =
            entityManager.createNamedQuery("Habitat.findById");
        query.setParameter(1, new Long(1));
        Habitat habitat = (Habitat) query.getSingleResult();
        Date oldModified = habitat.getModified();
        habitat.setTitle("Modified Title " + System.currentTimeMillis());
        entityManager.getTransaction().begin();
        entityManager.persist(habitat);
        entityManager.getTransaction().commit();
        entityManager.close();
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.merge(habitat);
        Assert.assertTrue("old date should be before updated", oldModified
            .before(habitat.getModified()));
    }
}
