package org.permacode;

import java.util.Date;

public class Habitat extends AtomicEntity
{
    private static final long serialVersionUID = -4057308541301713754L;

    private String title;

    /** Default constructor. */
    public Habitat()
    {
        super();
    }

    /** Constructor with id, only used in testing for convenience. */
    public Habitat(Long newId)
    {
        setId(newId);
    }

    /**
     * Constructor for normal use, only chance to set owner and created.
     * 
     * @param newOwnerId who owns this
     * @param newCreated when
     */
    public Habitat(Long newOwnerId, Date newCreated)
    {
        super(newOwnerId, newCreated);
    }

    private Long id;

    public Long getId()
    {
        return this.id;
    }

    public void setId(Long newId)
    {
        this.id = newId;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String newTitle)
    {
        title = newTitle;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((this.getId() == null) ? 0
            : this.getId().hashCode());
        result = prime * result + ((this.getTitle() == null) ? 0
            : this.getTitle().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object object)
    {
        if (this == object)
        {
            return true;
        }
        if (object == null)
        {
            return false;
        }
        if (!super.equals(object))
        {
            return false;
        }
        if (!(object instanceof Habitat))
        {
            return false;
        }
        Habitat other = (Habitat) object;
        boolean equal = isEqual(this.getId(), other.getId());
        equal &= isEqual(this.getTitle(), other.getTitle());
        return equal;
        
    }
}
