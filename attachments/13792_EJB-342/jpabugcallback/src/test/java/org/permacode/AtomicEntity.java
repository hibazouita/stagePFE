package org.permacode;

import java.io.Serializable;
import java.util.Date;
import java.util.logging.Logger;

public abstract class AtomicEntity implements Serializable
{
    private static Logger logger =
        Logger.getLogger(AtomicEntity.class.getCanonicalName());

    private Long version;

    private Long ownerId;

    private Date created;

    private Date modified;

    /** Default constructor. */
    public AtomicEntity()
    {
        super();
    }

    /**
     * Constructor for normal use, only chance to set owner and created.
     * 
     * @param newOwnerId who owns this
     * @param newCreated when
     */
    public AtomicEntity(Long newOwnerId, Date newCreated)
    {
        this.ownerId = newOwnerId;
        this.created = newCreated;
    }

    public void prePersistCallBack()
    {
        this.modified = new Date();
        logger.info("doing prePersistCallBack() - " + this + " - modified="
            + this.modified + " and created=" + this.created);
    }

    public Long getVersion()
    {
        return this.version;
    }

    public void setVersion(Long newVersion)
    {
        this.version = newVersion;
    }

    public Long getOwnerId()
    {
        return ownerId;
    }

    public Date getCreated()
    {
        return this.created;
    }

    public Date getModified()
    {
        return this.modified;
    }

    public void setModified(Date newModified)
    {
        this.modified = newModified;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.getCreated() == null) ? 0
            : this.getCreated().hashCode());
        result = prime * result + ((this.getModified() == null) ? 0
            : this.getModified().hashCode());
        result = prime * result + ((this.getOwnerId() == null) ? 0
            : this.getOwnerId().hashCode());
        result = prime * result + ((this.getVersion() == null) ? 0
            : this.getVersion().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object object)
    {
        if (this == object)
        {
            return true;
        }
        if (object == null)
        {
            return false;
        }
        if (getClass() != object.getClass())
        {
            return false;
        }
        AtomicEntity other = (AtomicEntity) object;
        boolean equal = isEqual(this.getCreated(), other.getCreated());
        equal &= isEqual(this.getModified(), other.getModified());
        equal &= isEqual(this.getOwnerId(), other.getOwnerId());
        equal &= isEqual(this.getVersion(), other.getVersion());
        return equal;
    }

    protected boolean isEqual(Object local, Object other)
    {
        if (local == null && other == null)
        {
            return true;
        }
        if (local == null)
        {
            return false;
        }
        return local.equals(other);
    }
}