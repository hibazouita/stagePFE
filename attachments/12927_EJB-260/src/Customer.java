import java.io.*;

import javax.persistence.*;

@Entity
@Table(name = "customer")
public class Customer
{
  private String customerId;

  public Customer()
  {

  }

  public Customer(String customerId)
  {
    this.customerId = customerId;
  }

  @Id
  @Column(name = "customer_id")
  public String getCustomerId()
  {
    return customerId;
  }

  public void setCustomerId(String customerId)
  {
    this.customerId = customerId;
  }

  public String toString()
  {
    return this.customerId;
  }
}
