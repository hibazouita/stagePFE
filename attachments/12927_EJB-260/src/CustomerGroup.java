import java.io.*;
import java.util.*;

import javax.persistence.*;

@Entity
@Table(name = "customer_group")
public class CustomerGroup implements Serializable
{
  private long id = -1;

  private String name;

  private Set<Customer> customers = new HashSet<Customer>();

  @Id
  @GeneratedValue
  @Column(name = "customer_group_id")
  public long getId()
  {
    return id;
  }

  public void setId(long id)
  {
    this.id = id;
  }

  @Basic
  @Column(name = "name", length = 255, nullable = false)
  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  @OneToMany(cascade = {})
  @JoinTable(name = "customer_group_customer",
             joinColumns = {@JoinColumn(name = "customer_group_id")},
             inverseJoinColumns = {@JoinColumn(name = "customer_id")})
  public Set<Customer> getCustomers()
  {
    return customers;
  }

  public void setCustomers(Set<Customer> customers)
  {
    this.customers = customers;
  }
} 