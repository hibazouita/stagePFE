import javax.persistence.*;

import org.hibernate.ejb.*;
import org.springframework.core.io.*;
import org.springframework.beans.factory.xml.*;

/**
 * User: Chadwick M. Baatz
 * Date: Jan 5, 2007
 */
public class TestCustomerGroup
{

  private static HibernateEntityManager EM = null;

  /**
   * This Test Does not work
   */
  public void testMergeOnlyNewCustomerWithDetachGroup()
  {
    // Create Detached object
    CustomerGroup group = new CustomerGroup();

    group.setId(1L);
    group.setName("Yet Another");

    group.getCustomers().add(new Customer("CID0002953"));
    group.getCustomers().add(new Customer("CID001696"));
    group.getCustomers().add(new Customer("CIDD803650"));
    group.getCustomers().add(new Customer("CIDD803997")); // This is our new customer to map

    EntityTransaction trans = EM.getTransaction();
    trans.begin();
    CustomerGroup managedGroup = EM.merge(group);
    trans.commit();

    // Show customers to prove the merge updates the context.
    System.out.println("CUSTOMERS IN MANAGED GROUP: " + managedGroup.getCustomers());
  }

  /**
   * This Test Works
   */
  public void testPersistNewCustomerWithExistingGroup()
  {
    CustomerGroup group = EM.find(CustomerGroup.class, 1L);

    Customer customer = new Customer("CIDD803997");
    group.getCustomers().add(customer);

    EntityTransaction trans = EM.getTransaction();
    trans.begin();
    EM.persist(group);
    trans.commit();
  }

  /**
   * This Test Works
   */
  public void testMergePersistNewCustomerWithDetachGroup()
  {
    // Create Detached object
    CustomerGroup group = new CustomerGroup();

    group.setId(1L);
    group.setName("Yet Another");

    group.getCustomers().add(new Customer("CID0002953"));
    group.getCustomers().add(new Customer("CID001696"));
    group.getCustomers().add(new Customer("CIDD803650"));

    EntityTransaction trans = EM.getTransaction();
    trans.begin();
    CustomerGroup managedGroup = EM.merge(group);
    trans.commit();

    managedGroup.getCustomers().add(new Customer("CIDD803997")); // This is our new customer to map

    trans.begin();
    EM.persist(managedGroup);
    trans.commit();
  }

  public static void main(String[] args)
  {
    try
    {
      ClassPathResource res = new ClassPathResource("/spring-hibernate.xml");
      XmlBeanFactory factory = new XmlBeanFactory(res);

      EntityManagerFactory emFactory = (EntityManagerFactory) factory.getBean("entityManagerFactory");
      EM = (HibernateEntityManager) emFactory.createEntityManager();

      TestCustomerGroup tcg = new TestCustomerGroup();
      tcg.testMergeOnlyNewCustomerWithDetachGroup();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }

  }
}
