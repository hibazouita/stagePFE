package com.sia.hibtest;

import com.sia.hibtest.entity.Detail;
import com.sia.hibtest.entity.Master;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import java.util.Properties;

public class HibernateSupport {
    public static final String DB_USER = "your user";
    public static final String DB_PASSWORD = "your password";
    public static final String DB_URL = "jdbc:oracle:thin:#########:1521:orcl";
    private EntityManagerFactory emf;
    private EntityManager em;
    static {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void begin() {
        getEm().getTransaction().begin();
    }

    public void end() {
        end(false);
    }

    public void end(boolean commit) {
        if (getEm().isOpen()) {
            try {
                getEm().flush();
            } finally {
                try {
                    if (commit) {
                        getEm().getTransaction().commit();
                    } else {
                        getEm().getTransaction().rollback();
                    }
                } finally {
                    getEm().close();
                    em = null;
                }
            }
        }
    }

    public EntityManagerFactory getEmf() {
        if (emf ==  null) {
            try {
                Properties props = new Properties();
                props.put("hibernate.show_sql", true);
                props.put("hibernate.format_sql", true);
                props.put("hibernate.connection.driver_class", "oracle.jdbc.OracleDriver");

                props.put(Environment.URL, DB_URL);
                props.put(Environment.USER, DB_USER);
                props.put(Environment.PASS, DB_PASSWORD);

                Configuration config = new Configuration();
                //addEntityClasses(config);
                config.addAnnotatedClass(Master.class);
                config.addAnnotatedClass(Detail.class);
                SessionFactory sessionFactory = config
                        .addProperties(props)
                        .buildSessionFactory();

                emf = sessionFactory;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return emf;
    }


    public EntityManager getEm() {
        if (em == null) {
            em = getEmf().createEntityManager();
        }

        return em;
    }

    public void shutdown() {
        if (getEm().isOpen()) {
            getEm().close();
        }
        getEmf().close();
    }
}
