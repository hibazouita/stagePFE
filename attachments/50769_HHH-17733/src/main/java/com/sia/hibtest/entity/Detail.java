package com.sia.hibtest.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.io.Serializable;

@Entity
@Table(name="HIB_TEST_DETAIL")
public class Detail implements Serializable {
	
	private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID_DETAIL", precision = 10, scale = 0)
	private Long idDetail;

    @Column(name = "NAME", length = 40)
	private String name;


	public Long getIdDetail() {
		return this.idDetail;
	}

	public void setIdDetail(Long idDetail) {
		this.idDetail = idDetail;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Detail detail = (Detail) o;

		return idDetail != null ? idDetail.equals(detail.idDetail) : detail.idDetail == null;
	}

	@Override
	public int hashCode() {
		return idDetail != null ? idDetail.hashCode() : 0;
	}

}
