package com.sia.hibtest;

import com.sia.hibtest.entity.Master;

public class Main {

    private HibernateSupport hibSupport;

    public static void main(String[] args) {
        Main hqlTest = new Main();
        hqlTest.test();
    }

    private void test() {
        hibSupport = new HibernateSupport();

        createTestDb();
        try {
            hibSupport.begin();
            try {
                testLongRaw();
            } finally {
                hibSupport.end(false);
            }


        } finally {
            dropTestDb();
            hibSupport.shutdown();
        }

    }

    private void testLongRaw() {
        hibSupport.getEm().createQuery("select m from Master m where m.id = :id", Master.class)
                .setParameter("id", 1L)
                .getResultList();
    }

    private void createTestDb() {
        hibSupport.begin();
        try {
            exec("CREATE TABLE HIB_TEST_MASTER(ID NUMBER(10,0), ID_DETAIL NUMBER(10,0), BINARY_DATA LONG RAW)");
            exec("INSERT INTO HIB_TEST_MASTER VALUES (1, 1, UTL_RAW.CAST_TO_RAW('binary data...'))");
            exec("CREATE TABLE HIB_TEST_DETAIL(ID_DETAIL NUMBER(10,0), NAME VARCHAR2(20))");
            exec("INSERT INTO HIB_TEST_DETAIL VALUES (1, 'TEST')");
        } finally {
            hibSupport.end(true);
        }
    }

    private void dropTestDb() {
        hibSupport.begin();
        try {
            exec("DROP TABLE HIB_TEST_MASTER");
            exec("DROP TABLE HIB_TEST_DETAIL");
        } finally {
            hibSupport.end(true);
        }
    }

    private void exec(String sql) {
        hibSupport.getEm().createNativeQuery(sql).executeUpdate();
    }

}
