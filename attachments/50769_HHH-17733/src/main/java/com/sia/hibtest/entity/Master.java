package com.sia.hibtest.entity;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity(name="Master")
@Table(name="HIB_TEST_MASTER")
public class Master implements Serializable {
    private static final long serialVersionUID = 1L;

    public Master() {}

	public byte[] getBinaryData() {
		return binaryData;
	}
	@Id
	@Column(name = "ID", precision = 10)
	private Long id;

	@Column(name = "ID_DETAIL", precision = 10)
	private Long idDetail;

	@Column(name="BINARY_DATA")
	private byte[] binaryData;

	//with ManyToOne:
	//	if there is no detail, it works
	//	if fetchtype is lazy, it works
	//@ManyToOne(fetch = FetchType.EAGER)

	//with OneToOne it fails

	//if I comment out the annotations and declare detail transient, it works

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_DETAIL", nullable = false, insertable = false, updatable = false)
	private Detail detail;

	public Long getId() {
		return id;
	}

	public Long getIdDetail() {
		return idDetail;
	}

	public Detail getDetail() {
		return detail;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Master other = (Master) obj;
		if (id == null) {
			return other.id == null;
		} else return id.equals(other.id);
	}
}

