This example demonstrates a problem with Oracle JDBC Driver and Hibernate 6.3+. It works with Hibernate 6.2.22 

It creates two simple tables on an Oracle DB. 
The first one is HIB_TEST_MASTER and it associated to the Master entity.
The second one is HIB_TEST_DETAIL and it associated to the Detail entity.

Master entity has a OneToOne association with Detail. Both master record and its associated detail exist in the database.

The problem occurs because Master has a LONG RAW field. When the query is executed, hibernate tries to get the columns but
an exception is thrown. 

Stream has already been closed [SQL State=99999, DB Errorcode=17027] 


The problem seems related to the Oracle jdbc driver, but it stopped working since Hibernate 6.3 
https://blog.jooq.org/oracle-long-and-long-raw-causing-stream-has-already-been-closed-exception/


## How to reproduce:

1. Change these constants according to your db
*HibernateSupport.java*

~~~java
public static final String DB_USER = "your user";
public static final String DB_PASSWORD = "your password";
public static final String DB_URL = "jdbc:oracle:thin:#########:1521:orcl";
~~~

1. Run Main.main()

Tested with:
- Oracle Database 18c Standard Edition 2 Release 18.0.0.0.0 - Production
- Windows 10


