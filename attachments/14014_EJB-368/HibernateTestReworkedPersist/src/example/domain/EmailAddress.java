package example.domain;


/**
 * @author James Barrow
 */
public class EmailAddress {

  private Integer id;
  private String emailAddress;

  public EmailAddress() {
  }

  public EmailAddress(String emailAddress) {
    setEmailAddress(emailAddress);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();

    sb.append(super.toString())
            .append(" emailAddress [").append(getEmailAddress()).append("]");

    return sb.toString();
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }
  
  public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }
}
