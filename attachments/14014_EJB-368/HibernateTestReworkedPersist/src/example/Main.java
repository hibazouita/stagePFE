package example;

import example.domain.Country;
import example.domain.Province;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

/**
 * Author: Henriette Harmse Date: 19-Jun-2008 Dariel Solutions
 */
public class Main {

  public static void main(String args[]) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("example");
    EntityManager em = emf.createEntityManager();

    EntityTransaction tx = em.getTransaction();
    System.out.println("################### tx="+tx);
    tx.begin();
    Country country = new Country("Country", 1);
    em.persist(country);
    tx.commit();
    em.close();


    EntityManager em1 = emf.createEntityManager();
    EntityTransaction tx1 = em1.getTransaction();

    System.out.println("################# tx1="+tx1);
    tx1.begin();
    try {
    	em1.persist(country);
    	tx1.commit();
        System.out.println( "should have thrown PersistenceException");
    }
    catch ( PersistenceException ex ) {
        tx1.rollback();
        System.out.println( "expected: " + ex );
    }
    em1.close();

    EntityManager em2 = emf.createEntityManager();
    EntityTransaction tx2 = em2.getTransaction();

    System.out.println("################# tx2="+tx2);
    tx2.begin();
    Province province = new Province("Province", country);

    try {
        em2.persist(province);
    	tx2.commit();
        System.out.println( "should have thrown PersistenceException");
    }
    catch ( PersistenceException ex ) {
        tx2.rollback();
        System.out.println( "expected:" + ex );
    }
    em2.close();

    EntityManager em3 = emf.createEntityManager();
    EntityTransaction tx3 = em3.getTransaction();

    System.out.println("################# tx3="+tx3);
    tx3.begin();
    Country country1 = em3.find(Country.class, country.getId());
    province = new Province("Province", country1);
    em3.persist(province);
    tx3.commit();
    em3.close();
  }

}
